package jdbc_maven_librarymanagement;

import java.util.Scanner;

public class MainController {

	public static void main(String[] args) throws Exception {
		System.out.println("Hello...from  Welcome page ");
		User user=new User();
		Crud crud=new Crud();
		Book book=new Book();
		
		do {

			Scanner scanner = new Scanner(System.in);
			
			System.out.println("Enter the your choice \n1.SingUp \n2.LogIn \n3.Exit");
			int choice = scanner.nextInt();
			switch (choice) {
			case 1: {
				System.out.println("Enter the id : ");
				int id=scanner.nextInt();
				System.out.println("Enter the name : ");
				String name=scanner.next();
				System.out.println("Enter the phone : ");
				long phone=scanner.nextLong();
				System.out.println("enter the email :");
				String email=scanner.next();
				System.out.println("enter the password :");
				String password=scanner.next();
				
				user.setId(id);
				user.setName(name);
				user.setPhone(phone);
				user.setEmail(email);
				user.setPassword(password);
				
				crud.sinupUp(user);
				break;
			}

			case 2: {
				System.out.println("Hey... User \nThis Is LOGIN PAGE : ");
				System.out.println("enter the email :");
				String email=scanner.next();
				System.out.println("enter the password :");
				String password=scanner.next();
				
				user.setEmail(email);
				user.setPassword(password);
				
				boolean result=crud.logIn(user);
				if (result) {
					
					do {
						
						System.out.println("Enter the choice for : \n1. Insert a Book \t2.Show all the Book \t3.Fetch Book by id \n4.Fetch Book by Name \t5.Fetch Book by author Name \t6.Fetch Book by Genres \n7.Update book \t8.Delete Book by id \t9. Delete Book by Name \n10.Delete book by Author Name \t11.Delete Book by Genres \t12. Logout ");
						int ip=scanner.nextInt();
						
						switch (ip) {
						case 1:
						{
							System.out.println("enter the book id : ");
							int id=scanner.nextInt();
							
							System.out.println("enter the book name :  ");
							String name=scanner.next();
							
						    System.out.println("enter the book author : ");
						    String author=scanner.next();

							System.out.println("enter the book price :  ");
							double price=scanner.nextDouble();
							
							System.out.println("enter the book genre :  ");
							String genres=scanner.next();
							
							book.setId(id);
							book.setName(name);
							book.setAuthor(author);
							book.setPrice(price);
							book.setGenres(genres);
							
							crud.addBook(book);
							break;
						}
						
						case 2:
						{
								
							crud.showBookAll(book);
							break;
						}
						
						case 3:
						{
							System.out.println("Enter the id :	");
							int id=scanner.nextInt();
							
							book.setId(id);
							crud.fetchBookById(book);
							break;
						}
						
						case 4:
						{
							System.out.println("Enter the Name :	");
							String name=scanner.next();
							
							book.setName(name);
							crud.FetchByName(book);
							break;
						}
						
						case 5:
						{
							System.out.println("Enter the Author :	");
							String author=scanner.next();
							
							book.setAuthor(author);
							crud.FetchByAuthor(book);
							break;
						}
						
						case 6:
						{
							System.out.println("Enter the Book Genres :	");
							String genres=scanner.next();
							
							book.setGenres(genres);
							crud.fetchByGenre(book);
							break;
						}
						
						case 7:
						{
							System.out.println("enter the book name :  ");
							String name=scanner.next();
							
						    System.out.println("enter the book author : ");
						    String author=scanner.next();

							System.out.println("enter the book price :  ");
							double price=scanner.nextDouble();
							
							System.out.println("enter the book genre :  ");
							String genres=scanner.next();
							
							System.out.println("enter the book id : ");
							int id=scanner.nextInt();
							
							book.setName(name);
							book.setAuthor(author);
							book.setPrice(price);
							book.setGenres(genres);
							book.setId(id);
							
							crud.updateBook(book);
							break;
						}
						
						case 8:
						{
							System.out.println("Enter the id :	");
							int id=scanner.nextInt();
							
							book.setId(id);
							crud.deleteById(book);
							break;
						}
						
						case 9:
						{
							System.out.println("Enter the Name :	");
							String name=scanner.next();
							
							book.setName(name);
							crud.deleteByName(book);
							break;
						}
						
						case 10:
						{
							System.out.println("Enter the Author :	");
							String author=scanner.next();
							
							book.setAuthor(author);
							crud.deleteByAuthor(book);
							break;
						}
						
						case 11:
						{
							System.out.println("Enter the GENRES :	");
							String genres=scanner.next();
							
							book.setGenres(genres);
							crud.deleteByGenres(book);
							break;
						}
						
						case 12:
						{
							System.out.println("Logout sucessfully...!!!");
							System.out.println("Have good day.....bye");
							System.exit(0);
						}

						default:
						{
							System.out.println("Oops...sorry you enter wrong choice....!!!");
							break;
						}
							
							
						}
						
					} while (true);
					
				} else {
					System.out.println("Invalid credentails");
				}
				break;
			}

			case 3: {
				System.out.println("User Exit sucessfully...!!!");
				System.out.println("Have good day.....bye");
				System.exit(0);
				
			}

			default:
			{
				System.out.println("Oops..!!\nYou enter wrong choice...");
				break;
			}
				
			}
		} while (true);

	}
}
