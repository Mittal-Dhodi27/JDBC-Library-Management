package jdbc_maven_librarymanagement;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

import javax.crypto.spec.PSource;

public class Crud {

	public Connection getConnection() throws Exception {

		FileReader fileReader = new FileReader("libconfig.properties");
		Properties properties = new Properties();
		properties.load(fileReader);

		Class.forName(properties.getProperty("className"));
		Connection connection = DriverManager.getConnection(properties.getProperty("url"),
				properties.getProperty("user"), properties.getProperty("password"));
		return connection;

	}

	public void sinupUp(User user) throws Exception {
		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection
				.prepareStatement("INSERT INTO USER (id,name,phone,email,password) VALUES (?,?,?,?,?)");
		preparedStatement.setInt(1, user.getId());
		preparedStatement.setString(2, user.getName());
		preparedStatement.setLong(3, user.getPhone());
		preparedStatement.setString(4, user.getEmail());
		preparedStatement.setString(5, user.getPassword());

		int result = preparedStatement.executeUpdate();
		if (result != 0) {
			System.out.println("inserted");
		} else {
			System.out.println("not inserted");
		}

		connection.close();

	}

	public boolean logIn(User user) throws Exception {
		Connection connection = getConnection();

		PreparedStatement preparedStatement = connection.prepareStatement("SELECT PASSWORD FROM USER WHERE EMAIL=(?) ");
		preparedStatement.setString(1, user.getEmail());

		String dbpass = null;
		ResultSet resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			dbpass = resultSet.getString("password");

		}
		connection.close();
		if (user.getPassword().equals(dbpass)) {
			return true;
		} else {
			return false;
		}
	}

	public void addBook(Book book) throws Exception {
		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO BOOK VALUES(?,?,?,?,?)");
		preparedStatement.setInt(1, book.getId());
		preparedStatement.setString(2, book.getName());
		preparedStatement.setString(3, book.getAuthor());
		preparedStatement.setDouble(4, book.getPrice());
		preparedStatement.setString(5, book.getGenres());

		int result = preparedStatement.executeUpdate();
		if (result != 0) {
			System.out.println(" Book inserted");
		} else {
			System.out.println("Book not inserted");
		}

		connection.close();
	}

	public void showBookAll(Book book) throws Exception {
		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM BOOK");
		ResultSet resultSet = preparedStatement.executeQuery();
		while (resultSet.next()) {
			System.out.println("Id : " + resultSet.getInt(1));
			System.out.println("Book Name : " + resultSet.getString("name"));
			System.out.println("Author Name : " + resultSet.getString("author"));
			System.out.println("Price : " + resultSet.getDouble("price"));
			System.out.println(" Genre : " + resultSet.getString(5));
			System.out.println("-------------------");
		}
		connection.close();
	}

	public void fetchBookById(Book book) throws Exception {

		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM BOOK WHERE ID=(?)");
		preparedStatement.setInt(1, book.getId());

		ResultSet resultSet = preparedStatement.executeQuery();

		boolean present = false;

		while (resultSet.next()) {
			present = true;
			System.out.println("Id : " + resultSet.getInt(1));
			System.out.println("Book Name : " + resultSet.getString("name"));
			System.out.println("Author Name : " + resultSet.getString("author"));
			System.out.println("Price : " + resultSet.getDouble("price"));
			System.out.println(" Genre : " + resultSet.getString(5));
			System.out.println("-------------------");
		}

		if (present) {

		} else {
			System.out.println("Id is invalid");
		}

		connection.close();

	}

	public void FetchByName(Book book) throws Exception {

		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM BOOK WHERE NAME=(?)");
		preparedStatement.setString(1, book.getName());

		ResultSet resultSet = preparedStatement.executeQuery();
		boolean present=false;
		while (resultSet.next()) {
			System.out.println("Id : " + resultSet.getInt(1));
			System.out.println("Book Name : " + resultSet.getString("name"));
			System.out.println("Author Name : " + resultSet.getString("author"));
			System.out.println("Price : " + resultSet.getDouble("price"));
			System.out.println(" Genre : " + resultSet.getString(5));
			System.out.println("-------------------");
		}

		if (present) {

		} else {
			System.out.println("Name is invalid");
		}
		connection.close();

	}

	public void FetchByAuthor(Book book) throws Exception {

		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM BOOK WHERE AUTHOR=(?)");
		preparedStatement.setString(1, book.getAuthor());

		ResultSet resultSet = preparedStatement.executeQuery();
		boolean present=false;
		while (resultSet.next()) {
			System.out.println("Id : " + resultSet.getInt(1));
			System.out.println("Book Name : " + resultSet.getString("name"));
			System.out.println("Author Name : " + resultSet.getString("author"));
			System.out.println("Price : " + resultSet.getDouble("price"));
			System.out.println(" Genre : " + resultSet.getString(5));
			System.out.println("-------------------");
		}

		if (present) {

		} else {
			System.out.println("Author name is invalid");
		}

		connection.close();

	}

	public void fetchByGenre(Book book) throws Exception {

		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM BOOK WHERE GENRES=(?)");
		preparedStatement.setString(1, book.getGenres());

		ResultSet resultSet = preparedStatement.executeQuery();
		boolean present=false;
		while (resultSet.next()) {
			System.out.println("Id : " + resultSet.getInt(1));
			System.out.println("Book Name : " + resultSet.getString("name"));
			System.out.println("Author Name : " + resultSet.getString("author"));
			System.out.println("Price : " + resultSet.getDouble("price"));
			System.out.println(" Genre : " + resultSet.getString(5));
			System.out.println("-------------------");
		}

		if (present) {

		} else {
			System.out.println("Invalid Genre....");
		}

		connection.close();

	}

	public void updateBook(Book book) throws Exception {
		Connection connection = getConnection();
		PreparedStatement psPreparedStatement = connection
				.prepareStatement("UPDATE BOOK SET NAME=?,AUTHOR=?,PRICE=?,GENRES=?  WHERE ID=?");
		psPreparedStatement.setString(1, book.getName());
		psPreparedStatement.setString(2, book.getAuthor());
		psPreparedStatement.setDouble(3, book.getPrice());
		psPreparedStatement.setString(4, book.getGenres());
		psPreparedStatement.setInt(5, book.getId());

		int result = psPreparedStatement.executeUpdate();
		if (result != 0) {
			System.out.println("Updated");
		} else {
			System.out.println("Not upadte");
		}
		connection.close();
	}

	public void deleteById(Book book) throws Exception {
		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM BOOK WHERE ID=(?)");

		preparedStatement.setInt(1, book.getId());
		int res = preparedStatement.executeUpdate();

		if (res != 0) {
			System.out.println("deleted");
		} else {
			System.out.println("not deleted");
		}
		connection.close();
	}

	public void deleteByName(Book book) throws Exception {

		Connection connection = getConnection();
		PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM BOOK WHERE NAME=(?)");

		preparedStatement.setString(1, book.getName());
		int res = preparedStatement.executeUpdate();

		if (res != 0) {
			System.out.println("deleted");
		} else {
			System.out.println("not deleted");
		}
		connection.close();

	}

	public void deleteByAuthor(Book book) throws Exception {
		Connection connection = getConnection();

		PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM BOOK WHERE AUTHOR=(?)");

		preparedStatement.setString(1, book.getAuthor());
		int res = preparedStatement.executeUpdate();

		if (res != 0) {
			System.out.println("deleted");
		} else {
			System.out.println("not deleted");
		}
		connection.close();

	}

	public void deleteByGenres(Book book) throws Exception {

		Connection connection = getConnection();

		PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM BOOK WHERE GENRES=(?)");

		preparedStatement.setString(1, book.getGenres());
		int res = preparedStatement.executeUpdate();

		if (res != 0) {
			System.out.println("deleted");
		} else {
			System.out.println("not deleted");
		}
		connection.close();
	}
}
